James Hubbard Lab 3
ECE 40862

Pushbutton:
	- Power and ground connected to 3V and GND pins
	- Signal connected to pin 33
Touch sensor:
	- The wire for my touch sensing is connected to pin 14

Video:
	https://youtu.be/uQR-2qYjE1o
